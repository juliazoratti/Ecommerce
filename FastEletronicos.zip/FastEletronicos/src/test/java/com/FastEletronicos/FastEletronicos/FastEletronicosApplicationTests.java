package com.FastEletronicos.FastEletronicos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FastEletronicosApplicationTests {

	@Test
	void contextLoads() {
	}

}
